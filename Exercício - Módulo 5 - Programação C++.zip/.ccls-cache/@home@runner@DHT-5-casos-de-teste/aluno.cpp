#include "cliente.h"

Cliente::Cliente(){
  this->ra   = -1;
  this->nome = "";
};  
Cliente::Cliente(int ra, std::string nome){
  this->ra    = ra;
  this->nome  = nome;
}
string Cliente::getNome() const {
  return nome;
}
int Cliente::getRa() const{
  return ra;
}