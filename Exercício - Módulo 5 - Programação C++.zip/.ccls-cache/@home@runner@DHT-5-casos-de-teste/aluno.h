#include <iostream>
using namespace std;

class Cliente{
private :
  int         ra;
  std::string nome;  
public:  
  Cliente();
  Cliente(int ra, std::string nome);
  string getNome() const;
  int getRa() const;
};